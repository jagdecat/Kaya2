
import React from 'react';

type IconProps = {
  className?: string;
};

export const FeatherIcon: React.FC<IconProps> = ({ className = "w-12 h-12" }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.375 12.067c0 2.497 1.03 4.78 2.73 6.48 1.7 1.7 3.984 2.73 6.48 2.73s4.78-1.03 6.48-2.73c1.7-1.7 2.73-3.984 2.73-6.48s-1.03-4.78-2.73-6.48c-1.7-1.7-3.984-2.73-6.48-2.73-2.496 0-4.78 1.03-6.48 2.73-1.7 1.7-2.73 3.983-2.73 6.48z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 14.25l6-6.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 12.75L15 10.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 11.25l3-3" />
  </svg>
);

export const DropletInHandIcon: React.FC<IconProps> = ({ className = "w-12 h-12" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M15.65 15.25C15.65 16.75 14.45 18.3 12.7 19.15C12.3 19.35 11.7 19.35 11.3 19.15C9.55 18.3 8.35 16.75 8.35 15.25C8.35 13.25 10 11.05 12 8.5C14 11.05 15.65 13.25 15.65 15.25Z" strokeMiterlimit="10"/>
    <path d="M5.42 15.93C4.2 15.35 2.75 15.42 2.75 17.2C2.75 19.33 4.89 21 7.22 21H16.78C19.11 21 21.25 19.33 21.25 17.2C21.25 15.42 19.8 15.35 18.58 15.93" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const SoapBarIcon: React.FC<IconProps> = ({ className = "w-12 h-12" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M21 9.7V14.3C21 17.7 19.2 19 16.5 19H7.5C4.8 19 3 17.7 3 14.3V9.7C3 6.3 4.8 5 7.5 5H16.5C19.2 5 21 6.3 21 9.7Z" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7 2V5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12 2V5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M17 2V5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const FaceShieldIcon: React.FC<IconProps> = ({ className = "w-12 h-12" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M7.5 12.5C7.5 14.7091 9.29086 16.5 11.5 16.5C12.5358 16.5 13.4727 16.0825 14.1566 15.4158C14.7188 14.8697 15.0938 14.1204 15.2281 13.2813C15.5 11.6 14.4 10 12.5 10H10.5C8.84315 10 7.5 11.1193 7.5 12.5Z" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const SulfateFreeIcon: React.FC<IconProps> = ({ className = "w-12 h-12" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M19.38 10.38C19.77 11.33 20 12.36 20 13.44C20 17.2 16.96 20.24 13.2 20.24C9.44 20.24 6.4 17.2 6.4 13.44C6.4 10.32 8.44 7.69 11.13 6.77" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M14.5 5.5V2H9.5V5.5C9.5 6.6 10.4 7.5 11.5 7.5H12.5C13.6 7.5 14.5 6.6 14.5 5.5Z" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M4 4L20 20" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

export const FeatherTouchIcon: React.FC<IconProps> = ({ className = "w-12 h-12" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M12 2C6.48 2 2 6.48 2 12C2 17.52 6.48 22 12 22C17.52 22 22 17.52 22 12" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M12.75 12.75L15 10.5" />
    <path d="M9 14.25l6-6.25" />
    <path d="M9 11.25l3-3" />
  </svg>
);

export const PhFriendlyIcon: React.FC<IconProps> = ({ className = "w-12 h-12" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" strokeWidth="1.5">
    <path d="M22 11.41C22 16.71 16.71 22 11.41 22C6.11 22 1 16.71 1 11.41C1 6.11 6.11 1 11.41 1" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M6.2 17.8L17.8 6.2" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M10.15 6.69C10.15 7.69 9.34 8.5 8.34 8.5C7.34 8.5 6.53 7.69 6.53 6.69C6.53 5.69 7.34 4.88 8.34 4.88C9.34 4.88 10.15 5.69 10.15 6.69Z" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M19.12 15.5C19.12 16.5 18.31 17.31 17.31 17.31C16.31 17.31 15.5 16.5 15.5 15.5C15.5 14.5 16.31 13.69 17.31 13.69C18.31 13.69 19.12 14.5 19.12 15.5Z" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
