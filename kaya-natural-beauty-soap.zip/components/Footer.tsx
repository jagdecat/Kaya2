
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#FBF6F0] border-t border-gray-200">
      <div className="container mx-auto px-6 py-8 text-center text-gray-500">
        <h3 className="text-2xl font-serif tracking-widest text-gray-600">K A Y A</h3>
        <p className="mt-2 text-sm">Gentle luxury for every skin type.</p>
        <p className="mt-6 text-xs">&copy; {new Date().getFullYear()} KAYA Beauty. All Rights Reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
