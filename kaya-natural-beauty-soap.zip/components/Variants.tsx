
import React from 'react';

interface VariantCardProps {
  imgSrc: string;
  name: string;
  description: string;
}

const VariantCard: React.FC<VariantCardProps> = ({ imgSrc, name, description }) => (
  <div className="bg-white rounded-lg shadow-lg overflow-hidden group transform hover:-translate-y-2 transition-transform duration-300">
    <div className="aspect-w-1 aspect-h-1">
        <img src={imgSrc} alt={`KAYA Soap - ${name}`} className="object-cover w-full h-full" />
    </div>
    <div className="p-6 text-center">
      <h4 className="font-serif text-2xl font-semibold text-gray-800">{name}</h4>
      <p className="mt-1 text-gray-500">{description}</p>
    </div>
  </div>
);

const Variants: React.FC = () => {
  const variants = [
    { imgSrc: "https://i.imgur.com/3fMAbCj.png", name: "Vanilla Bouquet", description: "With Vanilla Extract" },
    { imgSrc: "https://i.imgur.com/8aV5R6h.png", name: "Cool Cucumber", description: "Beauty Cream Bar" },
    { imgSrc: "https://i.imgur.com/2s7CqB2.png", name: "Coconut Cream", description: "With Coconut Oil" },
  ];

  return (
    <section className="py-20 sm:py-28">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl lg:text-5xl font-semibold">Discover Your Scent</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">A gentle formula, available in a variety of delicate fragrances.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {variants.map((variant) => (
            <VariantCard key={variant.name} {...variant} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Variants;
