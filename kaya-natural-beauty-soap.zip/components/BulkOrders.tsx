import React, { useState } from 'react';

const BulkOrders: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    companyName: '',
    quantity: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch('/api/submit-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Something went wrong. Please try again.');
      }

      setSubmitted(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <section className="py-20 sm:py-28 bg-[#FBF6F0]">
        <div className="container mx-auto px-6 text-center">
          <h2 className="font-serif text-4xl lg:text-5xl font-semibold">Thank You!</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Your inquiry has been received. We will get back to you shortly.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 sm:py-28 bg-[#FBF6F0]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl lg:text-5xl font-semibold">Wholesale & Bulk Orders</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
            Interested in carrying KAYA in your store or placing a bulk order? Fill out the form below and we'll get in touch with you.
          </p>
        </div>
        <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8">
          <form onSubmit={handleSubmit} noValidate>
            {error && <div className="text-red-600 text-center mb-6 p-3 bg-red-100 rounded-md border border-red-200">{error}</div>}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  name="fullName"
                  id="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#C4A484] focus:outline-none transition duration-150 ease-in-out"
                  aria-label="Full Name"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#C4A484] focus:outline-none transition duration-150 ease-in-out"
                  aria-label="Email Address"
                />
              </div>
            </div>
            <div className="mt-6">
              <label htmlFor="companyName" className="block text-sm font-medium text-gray-700 mb-1">Company Name (Optional)</label>
              <input
                type="text"
                name="companyName"
                id="companyName"
                value={formData.companyName}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#C4A484] focus:outline-none transition duration-150 ease-in-out"
                aria-label="Company Name"
              />
            </div>
            <div className="mt-6">
              <label htmlFor="quantity" className="block text-sm font-medium text-gray-700 mb-1">Estimated Quantity</label>
              <select
                name="quantity"
                id="quantity"
                value={formData.quantity}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#C4A484] focus:outline-none transition duration-150 ease-in-out bg-white appearance-none"
                aria-label="Estimated Quantity"
              >
                <option value="" disabled>Please select</option>
                <option value="100-500">100 - 500 units</option>
                <option value="501-1000">501 - 1,000 units</option>
                <option value="1001-5000">1,001 - 5,000 units</option>
                <option value="5000+">5,000+ units</option>
              </select>
            </div>
            <div className="mt-6">
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
              <textarea
                name="message"
                id="message"
                rows={4}
                value={formData.message}
                onChange={handleChange}
                required
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-[#C4A484] focus:outline-none transition duration-150 ease-in-out"
                aria-label="Message"
                placeholder="Tell us a bit about your business and what you're looking for."
              ></textarea>
            </div>
            <div className="mt-8 text-center">
              <button
                type="submit"
                disabled={isSubmitting}
                className="bg-[#8B7355] text-white font-bold py-3 px-8 rounded-full hover:bg-[#A08466] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#C4A484] transition-colors duration-300 disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Submitting...' : 'Submit Inquiry'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default BulkOrders;
