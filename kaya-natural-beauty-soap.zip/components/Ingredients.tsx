
import React from 'react';

const Ingredients: React.FC = () => {
  return (
    <section className="py-20 sm:py-28 bg-[#FBF6F0]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl lg:text-5xl font-semibold">Pure & Simple Formulation</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            We believe in transparency and quality. KAYA is crafted from a blend of gentle cleansing agents and moisturizing ingredients, ensuring a kind-to-skin experience.
          </p>
        </div>
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden md:flex">
          <div className="md:w-1/2 p-8 lg:p-12">
            <h3 className="font-serif text-2xl font-semibold text-gray-800">Product Description</h3>
            <p className="mt-4 text-gray-600 leading-relaxed">
              Enriched with moisturizing agents and crafted with a high Total Fatty Matter (56–60%) base, KAYA produces a rich, creamy lather that cleans without stripping the skin. Infused with our signature Vanilla Bouquet fragrance, this bar softens, soothes, and leaves your skin feeling wonderful after every wash.
            </p>
            <p className="mt-4 text-gray-500 text-sm">
                Free from parabens and harsh sulfates. Not tested on animals.
            </p>
          </div>
          <div className="md:w-1/2 p-8 lg:p-12 bg-gray-50 border-t md:border-t-0 md:border-l border-gray-200">
            <h3 className="font-serif text-2xl font-semibold text-gray-800">Ingredients (INCI)</h3>
            <p className="mt-4 text-gray-600 font-mono text-xs leading-6">
              Sodium Palmate, Sodium Palm Kernelate, Water (Aqua), Glyceryl Caprate, CAP Betain, Sodium Cocoyl Isethionate, Titanium Dioxide, Fragrance (Vanilla Bouquet), Sodium Chloride, Tetrasodium EDTA, Tetrasodium Etidronate, Citric Acid.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Ingredients;
