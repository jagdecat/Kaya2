
import React from 'react';

interface TestimonialCardProps {
  quote: string;
  author: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ quote, author }) => (
  <div className="bg-white p-8 rounded-lg shadow-md border border-gray-100">
    <blockquote className="text-lg text-gray-600 italic border-l-4 border-[#C4A484] pl-6">
      "{quote}"
    </blockquote>
    <p className="mt-4 text-right font-semibold text-gray-800">— {author}</p>
  </div>
);

const Testimonials: React.FC = () => {
  const testimonials = [
    { quote: "My skin has never felt softer. KAYA is now a staple in my daily routine. The vanilla scent is so calming!", author: "Jessica M." },
    { quote: "Finally, a beauty bar that doesn't dry out my sensitive skin. It feels so luxurious and gentle.", author: "Sarah L." },
    { quote: "The creamy lather is incredible. It feels like a high-end product but is perfect for everyday use.", author: "Emily R." },
  ];

  return (
    <section className="py-20 sm:py-28">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl lg:text-5xl font-semibold">Loved by Many</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">Hear what our community is saying about their KAYA experience.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} quote={testimonial.quote} author={testimonial.author} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
