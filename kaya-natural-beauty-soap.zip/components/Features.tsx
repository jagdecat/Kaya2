
import React from 'react';
import { DropletInHandIcon, SoapBarIcon, FaceShieldIcon, SulfateFreeIcon, FeatherTouchIcon, PhFriendlyIcon } from './icons';

interface FeatureItemProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const FeatureItem: React.FC<FeatureItemProps> = ({ icon, title, description }) => (
  <div className="flex flex-col items-center text-center p-4">
    <div className="mb-4 text-[#8B7355]">{icon}</div>
    <h4 className="font-bold text-lg text-gray-800">{title}</h4>
    <p className="mt-1 text-gray-500 text-sm">{description}</p>
  </div>
);

const Features: React.FC = () => {
  const features = [
    { icon: <DropletInHandIcon />, title: "With Glycerin", description: "Attracts moisture for hydrated, supple skin." },
    { icon: <SoapBarIcon />, title: "High TFM (56-60%)", description: "Ensures a superior, creamy, and moisturizing lather." },
    { icon: <FaceShieldIcon />, title: "Dermatologically Gentle", description: "Tested to be mild and safe for sensitive skin types." },
    { icon: <SulfateFreeIcon />, title: "Sulfate-Free", description: "Cleanses effectively without harsh detergents." },
    { icon: <FeatherTouchIcon />, title: "Softens Skin", description: "Leaves skin feeling noticeably softer after every wash." },
    { icon: <PhFriendlyIcon />, title: "pH Friendly", description: "Helps maintain your skin's natural protective barrier." },
  ];

  return (
    <section className="py-20 sm:py-28">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl lg:text-5xl font-semibold">The KAYA Difference</h2>
          <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">Crafted with care, focusing on what your skin truly needs.</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {features.map((feature, index) => (
            <FeatureItem key={index} icon={feature.icon} title={feature.title} description={feature.description} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
