
import React from 'react';

const About: React.FC = () => {
  return (
    <section className="py-20 sm:py-28 bg-[#FBF6F0]">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
          <div className="flex justify-center">
            <img 
              src="https://i.imgur.com/3fMAbCj.png" 
              alt="KAYA Natural Beauty Soap Box" 
              className="rounded-lg shadow-2xl max-w-sm w-full object-contain"
            />
          </div>
          <div>
            <h3 className="font-serif text-4xl lg:text-5xl font-semibold text-[#333333]">Gentle Luxury for Your Skin</h3>
            <p className="mt-6 text-lg text-gray-600 leading-relaxed">
              KAYA is a premium skincare beauty bar created for a gentle, effective daily cleansing experience. Its rich, creamy lather cleans without stripping the skin's natural moisture, leaving you feeling soft, soothed, and delicately scented.
            </p>
            <div className="mt-8 p-6 bg-white/70 rounded-lg shadow-inner border border-gray-200">
                <div className="flex items-center space-x-3">
                    <span className="text-2xl font-bold bg-[#C4A484] text-white rounded-full px-4 py-1">3 in 1</span>
                    <div className="text-gray-700">
                        <p className="font-semibold">Cleanses. Softens.</p>
                        <p className="font-semibold">Gentle on Skin.</p>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
