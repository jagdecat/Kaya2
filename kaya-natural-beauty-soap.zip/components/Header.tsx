
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-[#FDFBF8]/80 backdrop-blur-sm">
      <div className="container mx-auto px-6 py-4">
        <h1 className="text-3xl font-serif font-bold text-charcoal tracking-widest">
          K A Y A
        </h1>
      </div>
    </header>
  );
};

export default Header;
