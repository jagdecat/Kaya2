
import React from 'react';
import { FeatherIcon } from './icons';

const Hero: React.FC = () => {
  return (
    <section 
      className="relative min-h-[80vh] flex items-center justify-center text-center text-white bg-cover bg-center"
      style={{ backgroundImage: `url('https://i.imgur.com/L3h9a3h.jpg')` }}
    >
      <div className="absolute inset-0 bg-black/30"></div>
      <div className="relative z-10 p-6 flex flex-col items-center">
        <div className="mb-4 flex items-center justify-center h-28 w-28 rounded-full border-2 border-white/80">
           <FeatherIcon className="w-16 h-16 text-white/90" />
        </div>
        <h2 className="text-6xl md:text-8xl font-serif tracking-widest">K A Y A</h2>
        <p className="mt-2 text-xl md:text-2xl font-serif">Natural Beauty Soap</p>
        <div className="mt-6 bg-[#C4A484]/80 backdrop-blur-sm px-6 py-2 rounded-full">
          <p className="text-lg md:text-xl font-medium tracking-wide">For Soft, Radiant Skin</p>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center space-x-2 text-sm text-white/80">
          <span>Scroll Down</span>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </div>
    </section>
  );
};

export default Hero;
