// This file should be placed in the `api` directory at the root of your project.
// e.g., /api/submit-order.tsx
// Vercel will automatically turn this into a serverless function.

// We can't import this type as it's not in the provided files, but this is what the types would be.
// import type { VercelRequest, VercelResponse } from '@vercel/node';

export default async function handler(
  request: any, // VercelRequest
  response: any, // VercelResponse
) {
  if (request.method !== 'POST') {
    return response.status(405).json({ message: 'Method Not Allowed' });
  }

  const { fullName, email, companyName, quantity, message } = request.body;

  // --- Basic Validation ---
  if (!fullName || !email || !quantity || !message) {
    return response.status(400).json({ message: 'Missing required fields. Please fill out the entire form.' });
  }

  // --- 1. Save to Database (Placeholder) ---
  // In a real application, you would save the data to your database here.
  // This requires setting up a database (e.g., Vercel Postgres) and using its SDK.
  // You would use environment variables for your database connection string.
  // Example:
  //
  // import { sql } from '@vercel/postgres';
  // await sql`INSERT INTO inquiries (name, email, company, quantity, message)
  //           VALUES (${fullName}, ${email}, ${companyName}, ${quantity}, ${message});`;
  //
  console.log('DATABASE_PLACEHOLDER: Data to be saved:', request.body);


  // --- 2. Send Email Notification ---
  // Using a service like Resend (https://resend.com) is recommended for Vercel.
  // You must set RESEND_API_KEY and NOTIFICATION_EMAIL in your Vercel project's Environment Variables.
  const resendApiKey = process.env.RESEND_API_KEY;
  const emailTo = process.env.NOTIFICATION_EMAIL;

  if (!resendApiKey || !emailTo) {
      console.error('CRITICAL: Missing environment variables for email notification (RESEND_API_KEY, NOTIFICATION_EMAIL).');
      // Even if email fails, we can return success to the user if the DB save was successful.
      // For this example, we'll return an error to make debugging easier.
      return response.status(500).json({ message: 'Server configuration error.' });
  }

  const emailPayload = {
    from: 'KAYA Website <onboarding@resend.dev>', // This must be a verified domain in your Resend account.
    to: emailTo,
    subject: `New KAYA Wholesale Inquiry from ${fullName}`,
    html: `
      <h1>New Wholesale Inquiry</h1>
      <p>You have received a new inquiry from the KAYA website.</p>
      <ul>
        <li><strong>Name:</strong> ${fullName}</li>
        <li><strong>Email:</strong> <a href="mailto:${email}">${email}</a></li>
        <li><strong>Company:</strong> ${companyName || 'Not provided'}</li>
        <li><strong>Estimated Quantity:</strong> ${quantity}</li>
      </ul>
      <h2>Message:</h2>
      <p>${message}</p>
    `,
  };

  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${resendApiKey}`,
      },
      body: JSON.stringify(emailPayload),
    });

    if (!res.ok) {
        const errorData = await res.json();
        console.error('Failed to send email:', errorData);
        return response.status(500).json({ message: 'There was an issue sending your inquiry.' });
    }

  } catch (error) {
    console.error('Email sending error:', error);
    return response.status(500).json({ message: 'An unexpected error occurred.' });
  }

  // --- Return Success ---
  return response.status(200).json({ message: 'Submission received successfully!' });
}
